#!/bin/bash

if [ -z "$1" ]
then
  echo "Please supply a subdomain to create a certificate for";
  echo "e.g. mysite.localhost"
  exit;
fi

# Create a new private key if one doesnt exist, or use the xeisting one if it does
if [ -f device.key ]; then
  key_opt="-key"
else
  key_opt="-keyout"
fi

domain=$1
common_name=${2:-$1}
subject="/C=RU/ST=NSK/L=nsk/O=GNKPB3/CN=${common_name}/emailAddress=${email}"
num_of_days=3650
file_name=device # ${common_name}

openssl req -new -newkey rsa:2048 -sha256 -nodes $key_opt ${common_name}.key -subj "${subject}" -out ${common_name}.csr
cat v3.ext | sed s/%%DOMAIN%%/$common_name/g > __v3.ext
openssl x509 -req -in ${common_name}.csr -CA ./ca/rootCA.pem -CAkey ./ca/rootCA.key -CAcreateserial -out ${common_name}.crt -days $num_of_days -sha256 -extfile __v3.ext 

# move output files to final filenames
mv ${common_name}.csr $domain.csr
cp ${common_name}.crt $domain.crt

# remove temp file
#rm -f ${common_name}.crt;

echo 
echo "###########################################################################"
echo Done! 
echo "###########################################################################"
echo "To use these files on your server, simply copy both $DOMAIN.crt and"
echo "device.key to your webserver, and use like so (if Apache, for example)"
echo 
echo "    SSLCertificateFile    /path_to_your_files/$DOMAIN.crt"
echo "    SSLCertificateKeyFile /path_to_your_files/device.key"
