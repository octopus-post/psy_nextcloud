#!/bin/bash
common_name='gnkpb3.loc'
email='it-gnkpb3@yandex.ru'
subject="/C=RU/ST=NSK/L=nsk/O=GNKPB3/OU=IT/CN=${common_name}/emailAddress=${email}"
days='3650'
file_name='rootCA'
dirCA="$(pwd)/ca"
openssl genrsa -out ${dirCA}/${file_name}.key 2048
openssl req -x509 -new -nodes -key ${dirCA}/${file_name}.key -sha256 -days ${days} -out ${dirCA}/${file_name}.pem -subj ${subject}
